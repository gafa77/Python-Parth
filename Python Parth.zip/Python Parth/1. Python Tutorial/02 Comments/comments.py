# Comments

#This symbol represnts single line comment.  It is used to comment out the code. It is not executed.  It is used to explain the code.

#print("Hello, World!")
print("Hello, World!")

"""
This is a comment
written in
more than just one line.

This type of comment known as  a multiline comment.
"""

'''
print("Hello, World!")
'''
print("Hello, World!") 

