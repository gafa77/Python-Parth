# String Concatenation

#To concatenate, or combine, two strings you can use the + operator.

a = "Hello"
b = "World"
c = a + b
print(c)


#To add a space between them, add a " ":
a = "Hello"
b = "World"
c = a + " " + b
print(c)

