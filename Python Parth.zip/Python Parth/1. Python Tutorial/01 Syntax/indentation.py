# Python Indentation

"""
This first code indicates proper indentation.
indentation means spaces  at the beginning of a line to indicate that a line is part of the code on the line above it.
indentation can be gives by atleast 1 space.
"""

if 5 > 2:
 print("Five is greater than two!")  
if 5 > 2:
        print("Five is greater than two!") 



"""
This second code indicates improper indentation.
It has different amount of space  at the beginning of each line.
It will show  error.S
"""

#This example will produce an error in the result
"""               
    if 5 > 2:
 print("Five is greater than two!") 
        print("Five is greater than two!")

"""